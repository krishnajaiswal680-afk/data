Flight MCP Server + LLM-driven MCP Client
=========================================

Files:
- server_app.py        : FastAPI-based server exposing /call endpoint and tools
- client_nlu_llm.py    : Azure OpenAI helper that turns user text into {tool,args} JSON
- client_mcp.py        : Interactive CLI that uses LLM then calls server

Quick start:
1) Install dependencies:
   pip install -r requirements.txt

2) Set environment variables:
   export MONGODB_URL="mongodb://<user>:<pass>@<host>:<port>/"
   export DATABASE_NAME="jocflightdb_30_jan"
   export COLLECTION_METAR="flight"
   export AZURE_OPENAI_ENDPOINT="https://<your-resource>.openai.azure.com"
   export AZURE_DEPLOYMENT="gpt-4o"  # your azure deployment name
   export AZURE_API_KEY="<key>"
   export MCP_SERVER_URL="http://localhost:8000"

3) Run server:
   python server_app.py

4) Run client in another terminal:
   python client_mcp.py

Notes:
- The LLM is instructed to return strict JSON. If the model returns invalid JSON, parsing will fail.
- The server tools operate on the 'flight' collection in the 'jocflightdb_30_jan' database by default.
