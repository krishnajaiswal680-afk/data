"""MCP Client CLI that uses LLM to map natural text -> tool call, then calls server /call endpoint."""
import os
import json
import requests
from client_nlu_llm import parse_user_query

MCP_SERVER = os.getenv('MCP_SERVER_URL', 'http://localhost:8000')

def call_server(tool: str, args: dict):
    url = MCP_SERVER.rstrip('/') + '/call'
    payload = {'tool': tool, 'args': args or {}}
    resp = requests.post(url, json=payload, timeout=30)
    resp.raise_for_status()
    return resp.json().get('result')

def interactive():
    print('🛫 MCP Client (LLM-driven) — type exit to quit')
    while True:
        q = input('You: ').strip()
        if not q: continue
        if q.lower() in ('exit','quit'): break
        try:
            parsed = parse_user_query(q)
        except Exception as e:
            print('[LLM parse error]', e)
            continue
        tool = parsed.get('tool')
        args = parsed.get('args', {})
        print(f'-> Calling tool: {tool} with args: {json.dumps(args)}')
        try:
            res = call_server(tool, args)
            print('\n--- Result ---\n')
            print(res)
            print('\n' + '-'*60 + '\n')
        except Exception as e:
            print('[Server call error]', e)

if __name__ == '__main__':
    interactive()
